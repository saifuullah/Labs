#include <iostream>
#include <string.h>
#include <fstream>
#include <stdlib.h>
using namespace std;

                                    /**    THIS IS FIRST CLASS
                                    *
                                    *      CONTAIN SOME SETTERS,GATTERS
                                    *      AND SOME VARIABLES
                                    **/
class Node
{
private:
    Node *next;
    int data;
public:
    void setNextNode(Node *n)
    {   next=n;
    }

    void setData(int d)
    {   data=d;
    }

    int getData()
    {
         return data;
    }

    Node *getNextNode()
    {   return next;
    }

    Node(int d)
    {   next=NULL;
        data=d;
    }

    Node()
    {
         next=NULL;
    }

};/// CLASS END PARENTHESIS

/**       **********    First Class End      *************
*         *******       Second Class            **********
*         ****          Linked_List Class          *******
*
**/

class Linked_List
{
private:
    Node *first;
    Node *NONE;
    Node *new_ptr;
public:

Linked_List()
{
    first=NULL;
    NONE =NULL;
    new_ptr=NULL;
}
    void add_at_start(int dat)       ///THIS IS ADD AT START FUNCTION
    {   Node *temp=new Node(dat);
        Node *temp2=first;
        if(first==NULL)
            first=temp;
        else
        {   first=temp;
            temp->setNextNode(temp2);
        }
    }//End

  void add_at_end(int dat)      ///THIS FUNCTION WILL ADD AT END OF THE LIST
  {
      Node *temp=new Node(dat);
      Node *temp2=first;
      if(first==NULL)
        add_at_start(dat);
      else
      {
      while(temp2->getNextNode()!=NULL)
      {
          temp2=temp2->getNextNode();
      }
      temp2->setNextNode(temp);
      }
  }//END


    void display_all()             ///This Will display list
    {   Node *temp=first;
    if(first==NULL)
        cout<<"Sorry, List is Empty :)  "<<endl;
    else{
        while(temp !=NULL)
        {   cout<<temp->getData()<<endl;
            temp=temp->getNextNode();
        }
    }
    }//End

    void remove_first()          ///THIS WILL REMOVE THE FIRST VALUE
    {
        if(first==NULL)
            cout<<"Sorry, List is Empty Nothing to Delete :) "<<endl;

    else if(first->getNextNode()==NULL)
        first=NULL;
    else
        first=first->getNextNode();
    }//END


    void remove_last()            ///THIS WILL REMOVE THE LAST VALUE
    {

        Node *temp=first;
        if(first==NULL)
            cout<<"Sorry, List is Empty :) "<<endl;
        else if(first->getNextNode()==NULL)
            first=NULL;
        else
        {
            while(temp->getNextNode()->getNextNode()!=NULL)
            {
                temp=temp->getNextNode();
            }
        temp->setNextNode(NONE);
        }
    }//End

    void remove_wanted(int dat)      ///THIS WILL REMOVE THE USER GIVEN VALUE FROM LIST
    {
        Node *temp=first;
        int co=0;
        if(first==NULL)
            cout<<"Sorry, Data is not Found  "<<endl;
            else if(first->getData()==dat)
                first=first->getNextNode();
        else
        {
            Node *t=first;
            while(t->getNextNode()!=NULL)
            {
                if(t->getData()==dat)
                    co++;
            t=t->getNextNode();
            }
            if(co==0)
                cout<<"Sorry, Given Data is not Found "<<endl;
            else
            {
               temp=first;
                while(temp->getNextNode()->getData()!=dat)
            {
                temp=temp->getNextNode();
            }
            temp->setNextNode(temp->getNextNode()->getNextNode());
            }
 }
 }//END OF FUNCTION

int getSize()         ///THIS FUNCTION WILL GIVE THE SIZE
{
    int countr=0;
    Node *temp=first;
    if(temp==NULL)
        cout <<"Sorry, List is Empty >> "<<endl;
    else
    {
    while(temp!=NULL)
    {
        temp=temp->getNextNode();
        countr++;
    }
    }
    return countr;
}//END  OF FUNCTION

void remove_index(int ind)     ///THIS FUNCTION WILL REMOVE THE VALUE , WHICH INDEX IS GIVEN BY USER
{
    if(first == NULL)
        cout <<"Sorry, List is Empty "<<endl;
    else {
    Node *temp=first;
    int i=0;
    if(ind < 0)
        cout <<"Sorry, Wrong Index/Location is given : "<<endl;

    else
        if(ind > getSize())
        cout <<" Sorry, given Index Exceeds the Size of List "<<endl;

    else
        if(ind == 0)
        first = first->getNextNode();
    else
        if (ind==1)
        first ->setNextNode(first->getNextNode()->getNextNode());
    else
    {
    {
        for(i=1; i<ind ; i++)
            temp=temp->getNextNode();
    }
    temp->setNextNode(temp->getNextNode()->getNextNode());
    }
    }
}//END OF FUNCTION


void add_at_user_p(int dat, int indx)       ///THIS WILL ADD A NEW NODE AT USER GIVEN POSITION
{
    Node *temp2=new Node(dat);
    Node *temp=first;
    if(indx<0)
        add_at_start(dat);
    else if(indx>getSize())
        add_at_end(dat);
    else if(indx+1==getSize())
        add_at_end(dat);
    else
        {
        for (int i=1; i<indx; i++)
        {
            temp=temp->getNextNode();
        }
        temp2->setNextNode(temp->getNextNode());
        temp->setNextNode(temp2);
    }
}//END OF FUNCTION

void search_data(int dat)        ///THIS IS FOR SEARCHING DATA ON THE BASE OF
{                                ///      GIVEN DATA
    Node *temp=first;
    int co=0,x=0;
    while(temp!=NULL)
    {
        if(temp->getData()==dat)
            co++;
     temp=temp->getNextNode();
    }
    if(co==0)
        cout <<"Sorry, The Given Data is Not Found inThe List "<<endl;
    else
    {
        temp=first;
        while(temp->getData()!= dat)
        {
              temp=temp->getNextNode();
        x++;
         }
        cout <<"Data is Present in the list "<<endl;
    }
}//END OF FUNCTION

void show_data(int indxx)        ///THIS WILL SEARCH ON THE BASE OF INDEX
{
    Node *temp=first;
    if(indxx>getSize())
        cout <<"Sorry, the Given index Exceeds the Size of Linked List "<<endl;
    else if(indxx<0)
        cout <<"Sorry, Given Position is not correct "<<endl;
    else
    {
      for(int i=0; i<indxx; i++)
      {
          temp=temp->getNextNode();
      }
      cout <<"The Data At Given Location is "<<temp->getData()<<endl;
    }

}//END OF FUNCTION




};//class End

                /**
                *
                *                      MAIN FUNCTION START FROM HERE
                *
                **/










class chain
{
private:
    Linked_List hashTable[10];
public:

chain()
{

}


int hashFunction(int d)
{
    return d % 10;
}


void add(int d)
{
    int ind = hashFunction(d);
    hashTable[ind].add_at_start(d);

}

void del(int d)
{
    int ind = hashFunction(d);
    hashTable[ind].remove_wanted(d);
}
void serch(int d)
{
    int ind = hashFunction(d);
    hashTable[ind].search_data(d);
}



};










int main()
{   chain myList;
    char ch;
    int choice,dat;

    do           //do while loop start
    {
        system("CLS");

        cout<<"********************************************"<<endl;
        cout<<"1 For Add Value                          ***"<<endl;
        cout<<"2 For Delete Value                       ***"<<endl;
        cout<<"3 For Search Value                       ***"<<endl;
        cout<<"********************************************"<<endl;
        cout<<endl<<"Enter Your Choice : ";
        cin>>choice;

        switch(choice)
        {   case 1:
                cout<<"Enter Data to Add : ";
                cin>>dat;
                myList.add(dat);
                break;

            case 2:
                cout<<"Enter Data to be deleted : ";
                cin>>dat;
                myList.del(dat);
                break;
            case 3:
                cout<<"Enter data to search "<<endl;
                cin >> dat;
                myList.serch(dat);
                break;

            default :
                cout <<endl<<"Invalid Choice Entered "<<endl;

        }  //switch End
        cout<<endl<<"Do You Want To Continue : (y/n) : ";
        cin>>ch;
        cout <<endl<<endl;
    }
    while(ch!='n');

    return 0;
}
