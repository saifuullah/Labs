#include <iostream>
#include <time.h>
#include <stdlib.h>

using namespace std;

class sorting
{
public:
    int my_partition(int *Arr, int Start, int End)
    {   int Pivot = Arr[Start];
        int P = Start+1;

        int i;
        for (i = Start+1; i <= End; i++)
        {   if (Arr[i] <= Pivot)
            {

                swap(Arr[P], Arr[i]);
                P++;
            }
        }
        swap(Arr[P-1], Arr[Start]);
        return P-1;
    }

    int my_random_partition(int *myArray, int Start, int End)
    {   srand(time(NULL));
        int rI = Start + rand()%(End-Start);
        swap(myArray[rI], myArray[Start]);

        return my_partition(myArray,0,15);
    }

    void quickSort_R(int *myArray, int Start, int End)
    {   int partationIndex = 0;
        if (Start < End)
        {
            partationIndex = my_partition(myArray, Start, End);
            quickSort_R(myArray, Start, partationIndex - 1);
            quickSort_R(myArray, partationIndex + 1, End);
        }
    }

    void quicsort(int *a,int first, int last)
    {

        if(first<last)
        {
            int pi = my_partition(a,first, last);

            quicsort(a,first,pi-1);
            quicsort(a,pi+1, last);
        }
    }
};

int main()
{   sorting o;
    int n=9;
    int a[16]= {503,87,512,61,908,170,897,275,653,426,154,509,612,677,675,703};

    for(int i = 0; i<16; i++)
    {   cout << a[i] << " " ;
    }
    cout << "befor " <<endl<<endl;


    int b[16]= {503,87,512,61,908,170,897,275,653,426,154,509,612,677,675,703};

    o.quickSort_R(b,0,15);
    for(int i = 0; i<16; i++)
    {   cout << b[i] << " " ;
    }
    cout << "After " <<endl;
    return 0;
}
