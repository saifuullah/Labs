#include <iostream>

using namespace std;


class Heap{
private:
    int Data,index;
public:
    Heap()
    {
        Data = 0;
        index = 0;
    }

    void addData(int *a, int d)
    {
        int ind=index;
       a[index]=d;
       if(index!=0)
       checkMaxHeap(a,d,ind);
       index++;
    }

    void checkMaxHeap(int *a, int d, int ind)
    {

        if(d>a[((ind-1)/2)]) //data greater that parent
            swapData(a,ind);
            ind=(ind-1)/2;
            if(ind==0)
                return;
        checkMaxHeap(a,d,ind);

    }//end


    void swapData(int *a,int ind)
    {
        int c=a[(ind-1)/2];
        a[(ind-1)/2]=a[ind];
        a[ind]=c;
        return;

    }//end




    void deleteValue(int *a)
	{
	    int ind=index;
		if (ind > 0)
		{
			int temp;
			--ind;
			//cout << ind << endl;
			temp = a[ind];
			a[ind] = a[0];
			a[0] = temp;
			cout << " deleted element is " << a[ind] << endl;
			a[ind] = 0;
			//cout << a[0] << endl;
			index=ind;
			heapify_d(a, ind);
		}
		else
			cout << "Empty HEAP" << endl;
	}


	void heapify_d(int *a, int ind)
	{
		int i = 0;
		int temp;
		if (ind > 0)
		{
			while (a[i] < a[2*i+1] || a[i] < a[2*i+2])
			{
				if (a[(2 * i) + 1] > a[i])
				{
					temp = a[i];
					a[i] = a[(2 * i) + 1];
					a[(2 * i) + 1] = temp;
					i = (2 * i) + 1;
					continue;
				}
				if (a[(2 * i) + 2] > a[i])
				{
					temp = a[i];
					a[i] = a[(2 * i) + 2];
					a[(2 * i) + 2] =temp;
					i = (2 * i) + 2;
					continue;
				}
				if (a[(2 * i) + 1] < a[i] && a[(2 * i) + 2] < a[i])
				{
					break;
				}
			}
		}
		else
			cout << "Empty Array or HEAP" << endl;
	}






    void display(int *a)
    {
        for( int x =0;  x<index; x++)
        {
            cout<<a[x]<<endl;
        }
    }



    int getTop(int *a)
    {
        if(index==0)
            cout<<"Sorry, heap is Empty "<<endl;
        else
            return a[0];
    }




    int isHeap(int *a)
    {
        checkHeap(a,0);
    }

    int checkHeap(int *a, int ind)
    {
        if((2*ind)+1 > index)
        {
            cout<<"It is Heap "<<endl;
            return 1;
        }

        else
            if(a[(ind*2)+1] > a[ind] || a[(2*ind)+2] > a[ind])
        {
            cout <<"It is Not a Heap "<<endl;
            return 1;
        }
        else
            {
                int x= checkHeap(a, (2*ind)+1);
                if(x==0)
                checkHeap(a, (2*ind)+2);
            }
    }

};//Class End



int main()
{
    Heap myO;
    int limit;
    cout<<"Enter the number of elements you want to store in heap : " ;
    cin >>limit ;
       int box[limit]={23,19,76,45,22,1,44};
    for ( int i = 0; i<limit; i++)
    {
        if(box[i]!=0)
            {
                myO.addData(box,box[i]);
                cout << box[i] << endl;
            }
    }

    for(int i=0; i<limit; i++)
        myO.deleteValue(box);






    return 0;
}
