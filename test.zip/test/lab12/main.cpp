#include <iostream>

using namespace std;




class Heap{
private:
    int Data,index;
public:
    Heap()
    {
        Data = 0;
        index = 0;
    }

    void addData(int *a, int d)
    {
        int ind=index;
       a[index]=d;
       if(index!=0)
       checkMaxHeap(a,d,ind);
       index++;
    }

    void checkMaxHeap(int *a, int d, int ind)
    {

        if(d>a[((ind-1)/2)]) //data greater that parent
            swapData(a,ind);
            ind=(ind-1)/2;
            if(ind==0)
                return;
        checkMaxHeap(a,d,ind);

    }//end


    void swapData(int *a,int ind)
    {
        int c=a[(ind-1)/2];
        a[(ind-1)/2]=a[ind];
        a[ind]=c;
        return;

    }//end




    void deleteValue(int *a)
	{
	    int ind=index;
		if (ind > 0)
		{
			int temp;
			--ind;
			//cout << ind << endl;
			temp = a[ind];
			a[ind] = a[0];
			a[0] = temp;
			a[ind] = 0;
			//cout << a[0] << endl;
			index=ind;
			heapify_d(a, ind);
		}
		else
			cout << "Empty HEAP" << endl;
	}


	void heapify_d(int *a, int ind)
	{
		int i = 0;
		int temp;
		if (ind > 0)
		{
			while (a[i] < a[2*i+1] || a[i] < a[2*i+2])
			{
				if (a[(2 * i) + 1] > a[i])
				{
					temp = a[i];
					a[i] = a[(2 * i) + 1];
					a[(2 * i) + 1] = temp;
					i = (2 * i) + 1;
					continue;
				}
				if (a[(2 * i) + 2] > a[i])
				{
					temp = a[i];
					a[i] = a[(2 * i) + 2];
					a[(2 * i) + 2] =temp;
					i = (2 * i) + 2;
					continue;
				}
				if (a[(2 * i) + 1] < a[i] && a[(2 * i) + 2] < a[i])
				{
					break;
				}
			}
		}
		else
			cout << "Empty Array or HEAP" << endl;
	}



};//Class End











class sorting
{
public:
    void sortIt(int *a, int num)
    {
        if(num==0)
            return ;
        else if(a[num] < a[num-1])
        {
            int c=a[num];
            a[num]=a[num-1];
            a[num-1]=c;
            sortIt(a, (num-1));
        }
        else
            return ;
    }


    void moveMin(int *a, int f)
    {
        int x = searchMin(a, f);
        for(int i = 0; i<10; i++)
        {
            if(x==f)
            break;
            else
            {
                int c = a[x];
                a[x] = a[x-1];
                a[x-1] = c;
                x--;
            }
        }
    }




    int searchMin(int *a,int f)
    {
        int minn=10000,ind;
        for(int i = f; i<=9; i++)
        {
            if(a[i] < minn)
                {
                    minn = a[i];
                    ind = i;
                }
        }
        return ind;
    }





    void selection_sort(int *a, int last)
    {
        int num=1;
        for(int i=0; i<last; i++)
        {
            sortIt(a,num);
            num++;
        }
    }


    void selection_min(int *a, int last)
    {
        int f = 0;
        for(int x=0; x<last; x++)
        {
            moveMin(a, f);
            f++;
        }

    }

    void mergE(int *a, int f, int l)
    {
        int i = 0, j=f+1;
        int x = 0;
        while(x < l)
        {
            if((i-1)==f || (j-1)==l)
                break;
            else if(a[i] > a[j])
            {
                int c = a[i];
                a[i] = a[j];
                a[j] = c;
                j++;
            }
            else if(a[i] < a[j] )
            {
                i++;
            }
            x++;
        }

    }

    void mergeHeap(int *a, int *b)
    {
        Heap myh;
        int x=19;
        for( int i=0; i<20; i++)
        {
            b[x] = a[0];
            myh.deleteValue(a);
            x--;
        }


    }



}; //Class End















int main()
{
    Heap myH;

    //size = 10 ;
    int arr[20] = {11, 33, 55, 23, 24, 25, 32, 48, 88, 12, 45, 98, 14, 18, 38, 77, 73, 155, 12, 97};
    int arr2[20];
    sorting obj;

    for( int  i = 0; i < 20 ; i ++)
    {
        myH.addData(arr,arr[i]);
    }

    //obj.mergeHeap(arr, arr2);

    for(int i=0; i<19; i++)
        cout << arr2[i] << "   " ;
    return 0;
}

