#include<iostream>

using namespace std;


 void mergE(int *a, int f, int l)
    {
        int i = 0, j=f+1;
        int x = 0;
        while(x < l)
        {
            if((i-1)==f || (j-1)==l)
                break;
            else if(a[i] > a[j])
            {
                int c = a[i];
                a[i] = a[j];
                a[j] = c;
                j++;
            }
            else if(a[i] < a[j] )
            {
                i++;
            }
            x++;
        }

    }
// Merging 2 unsorted arrays into a sorted one
// Array one 1:  range ( 1.......n)
// Array two 2:  range ( a+1.....n)
// We divivde array into two parts
//Divide in Middle 1 to a and a+1 to n
void mergeIt(int arr[], int left, int middle, int right)
{
    int i, j, k;
    int n1 = middle - left + 1;
    int n2 =  right - middle;

//We create two arrays of half size of actual array
    int L[n1], R[n2];


    //copy data into these sub arrays
    // from actual array
    for (i = 0; i < n1; i++)
        L[i] = arr[left + i];

    for (j = 0; j < n2; j++)
        R[j] = arr[middle + 1+ j];

    //now merge them back


    i = 0; // Initial index of first sub-array
    j = 0; // Initial index of second sub-array
    k = left; // Initial index of mergeItd sub-array

    while (i < n1 && j < n2)
    {
        if (L[i] <= R[j])
        {
            arr[k] = L[i];
            i++;
        }
        else
        {
            arr[k] = R[j];
            j++;
        }
        k++;
    }

//Now if there are some elements remaining
//Put them in array
    while (i < n1)
    {
        arr[k] = L[i];
        i++;
        k++;
    }


    while (j < n2)
    {
        arr[k] = R[j];
        j++;
        k++;
    }
}


void mergeSort(int *a, int left, int right)
{
    if (right > left) // Also -- if( left != right )
    {

       //Middle
        int middle = (right+left)/2;


        //Divide array into small of parts
        //at least one
        //and one element is always sorted
        mergeSort(a, left, middle);
        //Divide right part of Array
        mergeSort(a, middle+1, right);
        mergeIt(a, left,middle, right);
    }
}

void pArray(int A[], int Size)
{
    cout << " " << endl;
    int i;
    for (i=0; i < Size; i++)
    cout <<A[i]<<", " ;
    cout <<endl<< " " << endl;
}


int main()
{
    int a[11] = {12, 19, 13, 5, 6, 7, 199, 243, 76, 45, 83};
    int Size = 11 ;
    cout << "Unsorted Array is :: " << endl;
    pArray(a, Size);
    int first = 0, last = Size-1;

    //Function Call
    mergeSort(a, first, last);
    //function Call

    cout << "Sorted Array is  :: " << endl ;
    pArray(a, Size);
    return 0;
}
