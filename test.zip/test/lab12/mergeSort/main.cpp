#include<iostream>
#include<stdlib.h>
#include<stdio.h>





// Merging 2 unsorted arrays into a sorted one
// Array one 1:  range ( 1.......n)
// Array two 2:  range ( a+1.....n)
// We divivde array into two parts
//Divide in Middle 1 to a and a+1 to n
void merge(int arr[], int left, int middle, int right)
{
    int i, j, k;
    int n1 = middle - left + 1;
    int n2 =  right - middle;

//We create two arrays of half size of actual array
    int L[n1], R[n2];


    //copy data into these sub arrays
    // from actual array
    for (i = 0; i < n1; i++)
        L[i] = arr[left + i];

    for (j = 0; j < n2; j++)
        R[j] = arr[middle + 1+ j];

    //now merge them back


    i = 0; // Initial index of first sub-array
    j = 0; // Initial index of second sub-array
    k = left; // Initial index of merged sub-array

    while (i < n1 && j < n2)
    {
        if (L[i] <= R[j])
        {
            arr[k] = L[i];
            i++;
        }
        else
        {
            arr[k] = R[j];
            j++;
        }
        k++;
    }

//Now if there are some elements remaining
//Put them in array
    while (i < n1)
    {
        arr[k] = L[i];
        i++;
        k++;
    }


    while (j < n2)
    {
        arr[k] = R[j];
        j++;
        k++;
    }
}


void mergeSort(int arr[], int left, int right)
{
    if (left < right)
    {

       //Middle
        int middle = left+(right-left)/2;


        //Divide array into small of parts
        //at least one
        //and one element is always sorted
        mergeSort(arr, left, middle);
        mergeSort(arr, middle+1, right);

        merge(arr, left, middle, right);
    }
}

void printArray(int A[], int size)
{
    int i;
    for (i=0; i < size; i++)
        printf("%d ", A[i]);
    printf("\n");
}


int main()
{
    int a[11] = {12, 19, 13, 5, 6, 7, 199, 243, 76, 45, 83};
    int Size = 11 ;

    printf("Given array is \n");
    printArray(a, Size);

    mergeSort(a, 0, Size - 1);

        cout << " Sorted Array is  :: " << endl ;
    printArray(a, Size);
    return 0;
}
