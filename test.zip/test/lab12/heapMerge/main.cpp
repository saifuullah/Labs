#include <iostream>

using namespace std;


class Heap{
private:
    int Data,index;
public:
    Heap()
    {
        Data = 0;
        index = 0;
    }

    void addData(int *a, int d)
    {
        int ind=index;
       a[index]=d;
       if(index!=0)
       checkMaxHeap(a,d,ind);
       index++;
    }

    void checkMaxHeap(int *a, int d, int ind)
    {

        if(d>a[((ind-1)/2)]) //data greater that parent
            swapData(a,ind);
            ind=(ind-1)/2;
            if(ind==0)
                return;
        checkMaxHeap(a,d,ind);

    }//end


    void swapData(int *a,int ind)
    {
        int c=a[(ind-1)/2];
        a[(ind-1)/2]=a[ind];
        a[ind]=c;
        return;

    }//end




   void heapify(int arr[], int n, int i)
{
    int largest = i; // Initialize largest as root
    int l = 2 * i + 1; // left = 2*i + 1
    int r = 2 * i + 2; // right = 2*i + 2

    // If left child is larger than root
    if (l < n && arr[l] > arr[largest])
        largest = l;

    // If right child is larger than largest so far
    if (r < n && arr[r] > arr[largest])
        largest = r;

    // If largest is not root
    if (largest != i) {
        swap(arr[i], arr[largest]);

        // Recursively heapify the affected sub-tree
        heapify(arr, n, largest);
    }
}

// Function to delete the root from Heap
int deleteRoot(int arr[], int& n)
{
    int last = arr[0];
    // Get the last element
    int lastElement = arr[n - 1];

    // Replace root with first element
    arr[0] = lastElement;

    // Decrease size of heap by 1
    n = n - 1;

    // heapify the root node
    heapify(arr, n, 0);
    return last;
}



    void display(int *a)
    {
        for( int x =0;  x<index; x++)
        {
            cout<<a[x]<<endl;
        }
    }



    int getTop(int *a)
    {
        if(index==0)
            cout<<"Sorry, heap is Empty "<<endl;
        else
            return a[0];
    }




    int isHeap(int *a)
    {
        checkHeap(a,0);
    }

    int checkHeap(int *a, int ind)
    {
        if((2*ind)+1 > index)
        {
            cout<<"It is Heap "<<endl;
            return 1;
        }

        else
            if(a[(ind*2)+1] > a[ind] || a[(2*ind)+2] > a[ind])
        {
            cout <<"It is Not a Heap "<<endl;
            return 1;
        }
        else
            {
                int x= checkHeap(a, (2*ind)+1);
                if(x==0)
                checkHeap(a, (2*ind)+2);
            }
    }

};//Class End



int main()
{
    Heap myO;
    int limit=7;

       int box[limit]={23,199,45,76,22,20,4};
    for ( int i = 0; i<limit; i++)
    {
        myO.addData(box,box[i]);
    }
 for ( int i=0; i<limit; i++)
 {
     cout << box[i] << endl;
 }

    return 0;
}




